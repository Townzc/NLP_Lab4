from mindformers import Trainer
import mindspore as ms

ms.set_context(mode=ms.GRAPH_MODE, device_target='Ascend', device_id=0)
cls_trainer = Trainer(task="text_generation", # 已支持的任务名
                      model="llama_7b",
                      pet_method="lora") # 已支持的模型名

question_set = [
    "Who is Huang Heyang?",
    "Tell me about alpacas.",
    "Where is Beijing?",
    "Where does afternoon come before morning in the world?",
    "Tell me about banana.", ]

for question_str in question_set:
    # 根据alpaca数据集的prompt模板，在instruction处填入自定义指令
    input_data = "Below is an instruction that describes a task. Write a response that appropriately completes the request.\n\n### Instruction:\n{}\n\n### Response:".format(question_str)

    lora_ckpt = "/home/ma-user/work/llama_lab/mindformers/scripts/mf_standalone/output/checkpoint/rank_0/llama_7b_lora_rank_0-20_5.ckpt"
    predict_result = cls_trainer.predict(input_data=input_data,
                                        predict_checkpoint=lora_ckpt)

    print(predict_result[0]["text_generation_text"][0])

