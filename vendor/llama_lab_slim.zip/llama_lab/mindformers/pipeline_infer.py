from mindformers.pipeline import pipeline
pipeline_task = pipeline(task="text_generation", model="llama_7b", max_length=50)
pipeline_result = pipeline_task("I love china, because", top_k=3)
print(pipeline_result)

